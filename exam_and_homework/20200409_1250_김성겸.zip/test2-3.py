
# 3-1 번
naver_closing_price = [474500, 461500, 501000, 500500, 488500]
print(naver_closing_price)

# 3-2 번
max_price = max(naver_closing_price)
print("최고 종가 : ",max_price)

# 3-3 번
min_price = min(naver_closing_price)
print("최저 종가 : ",min_price)

# 3-4 번
print("최고 종가와 최저 종가의 차이 : ", max_price - min_price)

# 3-5 번
print("수요일 종가 : ", naver_closing_price[2])

# 3-6 번
naver_closing_price2 = {'09/07':474500, '09/08':461500, '09/09':501000, '09/10': 500500, 
'09/11':488500}
print(naver_closing_price2, type(naver_closing_price2))

# 3-7 번
print("09/09의 종가 : ", naver_closing_price2['09/09'])
