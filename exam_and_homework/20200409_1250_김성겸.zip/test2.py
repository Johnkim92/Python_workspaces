"""
# 1번
name = input("이름을 입력하시오 : ")
age = int(input("나이를 입력하시오 : "))
age_in_2093 = int(age + (2093-2020))
print(name,"씨는 2093년에", age_in_2093,"살이시네요!")
"""

"""
# 2번
a = int(input("첫 번째 숫자를 입력하시오 : "))
b = int(input("두 번째 숫자를 입력하시오 : "))
c = int(input("세 번째 숫자를 입력하시오 : "))
average = float((a+b+c)/3)
print(a,b,c," 의 평균은 ",average," 입니다.")
"""
"""
# 3번
import math
radius = int(input("반지름을 입력하시오: "))
area = round(float(math.pi*radius**2), 3)
print("반지름이 ",radius," 인 원의 넓이 = ", area)
"""

"""
# 4번
import turtle
t = turtle.Turtle()
radius = 50

t.shape('turtle')
t.circle(radius)
t.up()
t.goto(100, 0)
t.down()
t.circle(radius+20)
t.up()
t.goto(200, 0)
t.down()
t.circle(radius+20+20)
"""

"""
# 5번
import turtle
t = turtle.Turtle()
t.shape('turtle')
side = 100
angle = 120
for i in range(1,4):
    t.forward(side)
    t.left(angle)
"""

"""
# 6번
# side = 200으로 수정해주면 된다.
# 혹은 t.forward(side*2)를 해주면된다.
"""

"""
# 7번
import turtle
t = turtle.Turtle()
t.shape('turtle')
side = 100
angle = 90

for i in range(1,5):
    t.forward(side)
    t.left(angle)

for i in range(1,5):
    t.forward(side)
    t.right(angle)

for i in range(1,5):
    t.forward(-side)
    t.left(angle)

for i in range(1,5):
    t.forward(-side)
    t.right(angle)
""" 
