
# 문제 4-1
for i in range(0,5):
    print('*', end='')


# 문제 4-2
for i in range(0,4):
    for j in range(0,5):
        print('*', end='')
    print('')


# 문제 4-3
for i in range(1,6):
    print('*'*i)


# 문제 4-4
for i in range(1, 6):
    print('*'*(6-i))


# 문제 4-5
for i in range(1,6):
    print(' '*(5-i), '*'*i)


# 문제 4-6
for i in range(0,5):
    print(' '*i, '*'*(5-i))


# 문제 4-7
for i in  range(1,10 ,2):
    print('{0:^9s}'.format('*'*i))



# 문제 4-8
for i in range(1, 10, 2):
    print('{0:^9s}'.format('*'*(10-i)))

# 문제 4-9
apart = [[101,102,103,104],[201,202,203,204],[301,302,303,304],[401,402,403,404]]
arrears = [101,203,301,404]

for a in apart:
    for b in a:
        if b in arrears:
            continue
        print("Newsdelivery!", b)
    
