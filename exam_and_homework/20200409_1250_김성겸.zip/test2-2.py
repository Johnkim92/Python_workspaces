"""
# 2-1 번
# daum_value = 89000
# naver_value = 751000
# daum_stock = 100
# naver_stock = 20
def tot_money (daum_stock, naver_stock, daum_value, naver_value):
    t = daum_stock*daum_value + naver_stock+naver_value
    return t
total = tot_money(100, 20, 89000, 751000)
print("보유 주식의 총액 : ",total)
"""

"""
# 2-2 번
# daum_value = 89000
# naver_value = 751000
# daum_stock = 100
# naver_stock = 20
# drop_daum = 5
# drop_naver = 10
def tot_money (daum_stock, naver_stock, daum_value, naver_value):
    t = daum_stock*daum_value + naver_stock+naver_value
    return t

def loss_money(drop_daum, drop_naver, daum_value, naver_value):
    mod_daum_value = int(daum_value*(100-drop_daum)/100)
    mod_naver_value = int(naver_value*(100-drop_naver)/100)
    loss = tot_money(100, 20, 89000, 751000) - tot_money(100, 20, mod_daum_value, mod_naver_value)
    return loss

loss = loss_money(5, 10, 89000, 751000)

print("손실액 : ",loss)
"""

"""
# 2-3 번
def change_f2c (f) :
    c = (f-32)/1.8
    return c
c = change_f2c(50)
print("섭씨 온도는 : ", c)
"""

"""
# 2-4 번
for i in range(1, 11):
    print("\"pizza\"")
"""

"""
# 2-5 번
price_naver = 1000000
for i in range(1,4):
    price_naver = price_naver*0.7
print(round(price_naver,1))
"""

"""
# 2-6 번
name = '파이썬'
addr = '20141212-1623210'
print("이름 : ",name,"생년월일:",addr[0:4],"년",addr[4:6],"월",addr[6:8],"일 주민등록번호:",addr)
"""

"""
# 2-7 번
s = 'Daum KaKao'
a,b = s.split()
s = a+" "+b
print(s)
"""

"""
# 2-8 번
a = 'hello world'
b = 'hi'
c = b+a[5:]
print(c)
"""

"""
# 2-9 번
x = 'abcdef'
x = x[1:]+x[0]
print(x)
"""
