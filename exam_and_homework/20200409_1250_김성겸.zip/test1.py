# 1번
print("\"환영합니다.\"")
print("\"파이썬의 세계에 오신 것을 환영합니다.\"")
print("\"파이썬은 강력합니다.\"")

"""
# 2번
반갑습니다. 파이썬!!
0.6
Hello World !!!
"""

"""
# 3번
day = int(24)
week = int(7 * day)
print(week)
168
"""

"""
# 4번
import turtle
t = turtle.Turtle()

t.shape('turtle')
length = 100
angle = 90

t.forward(length)
t.left(angle)
t.forward(length)
t.right(angle)
t.forward(length)
t.right(angle)
t.forward(length)
t.left(angle)
t.forward(length)
"""

"""
# 5번
import turtle
t = turtle.Turtle()
 
t.shape('turtle')
t.width(10)
length = 100
angle = 90
t.forward(length)
t.left(angle)
t.forward(length)
"""

"""
# 6번
import turtle
t = turtle.Turtle()
 
t.shape('turtle')
t.color('blue')
t.forward(100)
"""

"""
# 7번
import turtle
t = turtle.Turtle()

t.shape('square')
t.forward(100)
"""

"""
# 8번
import turtle
t = turtle.Turtle()

t.shape('turtle')
t.forward(100)
t.up()
t.goto(0,100)
t.down()
t.forward(100)
"""

"""
# 9번
import turtle
t = turtle.Turtle()
t.shape('turtle')
t.speed(30)
radious = 100
t.circle(radious)
t.up()
t.goto(150,0)
t.down()
t.circle(radious)
t.up()
t.goto(300,0)
t.down()
t.circle(radious)
t.up()
t.goto(75,-150)
t.down()
t.circle(radious)
t.up()
t.goto(225,-150)
t.down()
t.circle(radious)
"""
