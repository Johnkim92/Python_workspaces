""""
# 1번
a = int(input("숫자 1 입력란 : "))
b = int(input("숫자 2 입력란 : "))
sum = a+b
sub = abs(a-b)
mul = a*b
mean  = (a+b)/2
max = max(a,b)
min = min(a,b)
print("합 : ",sum)
print("차 : ",sub)
print("곱 : ",mul)
print("평균 : ",mean)
print("큰 수 : ",max)
print("작은 수 : ",min)
"""

"""
# 2번
import math
radius = int(input("반지름값 입력 : "))
height = int(input("원기둥의 높이 값 입력 : "))
volume = math.pi*height*radius**2
print("원기둥의 부피 : ",volume)
"""

"""
# 3번
num = int(input("정수를 입력해주세요 : "))
first = num % 10
second = (num % 100) // 10
third = (num % 1000) // 100
fourth = num // 1000
print("각 자리 수의 합은 : ",first+second+third+fourth)
"""

"""
# 4번 & 5번
import math
import turtle

x1, y1 = input("첫 번째 좌표를 띄어쓰기 형식으로 입력해주세요 : ").split()
x2, y2 = input("두 번째 좌표를 띄어쓰기 형식으로 입력해주세요 : ").split()
dist = math.sqrt((int(x1)-int(x2))**2 + (int(y1)-int(y2))**2)
print("두 좌표 사이의 거리는 : ",dist)

x1 = int(x1)
x2 = int(x2)
y1 = int(y1)
y2 = int(y2)

angle = math.degrees(math.atan(abs(y2-y1)/abs(x2-x1)))


t = turtle.Turtle()
t.shape('turtle')
t.color("blue")
t.up()
t.goto(x1,y1)
t.down()
t.forward(abs(x2-x1))
t.left(90)
t.forward(abs(y2-y1))

t.up()
t.goto(x1,y1)
t.down()
t.color("red")
t.right(angle)
t.forward(dist)
"""

"""
# 6번
import turtle

x1, y1 = input("첫 번째 좌표를 띄어쓰기 형식으로 입력해주세요 : ").split()
x2, y2 = input("두 번째 좌표를 띄어쓰기 형식으로 입력해주세요 : ").split()
x1 = int(x1)
x2 = int(x2)
y1 = int(y1)
y2 = int(y2)

t = turtle.Turtle()
t.shape('turtle')
t.up()
t.goto(x1,y1)
t.down()
t.goto(x2,y2)
t.ht()
t.write(t.distance(x1,y1))
"""

"""
# 7번
import time
t = time.time()
min = 60
hour = 60**2
day = 24*hour
month = 30 * day
year = 12 * month
t = int(t)
current_year = t//year + 1970
current_month = t % year // month + 1
current_day = t % year % month // day +1
current_hour = t % year % month % day // hour
current_min = t % year % month % day % hour // min
print(current_year,"년 ",current_month,"월 ", current_day,"일 ", current_hour,"시 ", current_min, "분")
"""

"""
# 8번
def kinetic_e (weight, velocity):
    kinetic_energy = 0.5*weight*velocity**2
    return kinetic_energy
weight = float(input("무게 입력 : "))
velocity = float(input("속도 입력 : "))

k = kinetic_e(weight, velocity)

print("운동에너지 값 : ", k)
"""
